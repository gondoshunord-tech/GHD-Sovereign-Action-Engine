import unittest, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import app as ghd

class GHDTests(unittest.TestCase):
    def setUp(self): self.c=ghd.app.test_client()
    def test_health(self):
        r=self.c.get('/health'); self.assertEqual(r.status_code,200); self.assertTrue(r.get_json()['ok'])
    def test_empty(self): self.assertEqual(self.c.post('/api/analyze',json={'text':''}).status_code,400)
    def test_demo_contract(self):
        r=self.c.post('/api/analyze',json={'text':'Urgent cleaning next week. 3-room flat.','context':'test'}); d=r.get_json(); self.assertEqual(r.status_code,200); self.assertFalse(d['live_ai']); self.assertIn('facts',d['result']); self.assertIn('missing_inputs',d['result'])
    def test_decision(self): self.assertTrue(self.c.post('/api/decision',json={'choice':'approve'}).get_json()['ok'])
if __name__=='__main__': unittest.main()
