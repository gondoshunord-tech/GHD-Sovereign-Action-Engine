# BuildMate — 3-minute pitch (English)

Hi, we're BuildMate.

Small construction and cleaning businesses don't just do physical work. Every job also creates a stream of admin: customer messages, missing job details, quote preparation, follow-ups, and often translation between languages.

For a small team, that work takes time away from the actual job.

BuildMate is an AI office assistant designed around those everyday workflows. A business owner pastes rough notes from a customer request. BuildMate turns them into a structured quote draft, a clear customer reply, or a job summary. It highlights missing details instead of pretending to know them, and it keeps a human in control before anything is sent.

Our first target is Swiss small businesses in construction and cleaning, where multilingual communication and lean office teams can make simple admin tasks surprisingly expensive.

Our prototype demonstrates the core workflow: choose the task and language, add the job notes, generate a draft, review the assumptions, and copy the result. The next step is to connect and evaluate a verified Apertus inference endpoint and test the system against anonymised real-world examples.

We won't measure success by how impressive one AI answer looks. We'll measure whether a business can prepare a customer response faster, whether the draft needs fewer edits, and whether owners would pay to use it every week.

Our business model is a simple subscription, with an entry tier and a team tier. Before scaling, we will validate pricing with local businesses and run small design-partner pilots.

BuildMate is not trying to replace skilled tradespeople or make binding pricing decisions. It gives small teams a practical assistant for repetitive office work, with transparent limitations and human approval.

We're looking for developers and pilot customers who want to build a useful, open, multilingual tool for Swiss SMEs.

Thank you.

## Demo sequence (60–90 seconds)
1. Select “Prepare a quote”.
2. Set language to German.
3. Paste an anonymised cleaning or construction request.
4. Generate draft.
5. Point out missing information and review checklist.
6. Explain that the current package uses demo fallback until a real Apertus endpoint is configured and verified.
7. State one measurable hypothesis: reduce first-draft preparation time; then validate with pilot users.

## Judge Q&A

**Why use Apertus?** The project is designed to test an open Swiss model in a practical multilingual business workflow. The actual endpoint and model must be configured and tested before claiming integration.

**How do you prevent hallucinations?** The prompt instructs the model not to invent prices or commitments, output labels missing information, and require human review. These are mitigations, not guarantees; we need an evaluation set and ongoing testing.

**Who pays?** Small construction and cleaning businesses with repetitive customer admin. We will validate this through interviews and pilots before treating the pricing hypothesis as proven.

**What is open source?** The project code and documentation can be published under the hackathon's required licences. Review the official terms and any track-specific licence instructions before submission.

**What is the biggest risk?** That users don't find enough repeated value to pay, or that the AI output requires too much editing. Our pilot will measure usage, edit rate, time saved, and willingness to pay.
