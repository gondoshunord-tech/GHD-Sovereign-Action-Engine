# BuildMate — business model (working draft)

## Customer and problem
Initial segment: Swiss micro and small construction, cleaning, property-maintenance and related service businesses (roughly 1–20 staff). Owners and office staff spend time rewriting messages, collecting details for quotes, and translating between customers and field workers.

This is a hypothesis to validate, not a proven market finding.

## Value proposition
Turn rough job notes into a consistent draft quickly, in the customer's preferred language, while keeping the owner in control. Focus on admin time saved rather than claiming AI replaces a qualified estimator.

## MVP
1. Paste customer request / site notes.
2. Select task and output language.
3. Generate a quote outline, customer reply, or job summary.
4. Review missing information and copy the draft.
5. Human verifies facts and prices before sending.

## Pricing hypotheses to test
- Starter: CHF 29/month for a limited number of drafts.
- Team: CHF 79/month for several staff and reusable company templates.
- Setup/onboarding: CHF 99–299 one-time for template configuration.

These are experiments to validate with customers, not researched market prices. Consider a paid pilot only after security and reliability are adequate.

## Go-to-market
1. Interview 10 local owners/office managers.
2. Ask them to show the last quote or customer reply that took too long (use anonymised examples).
3. Build a clickable demo for their most frequent workflow.
4. Offer 3 design-partner pilots with weekly feedback.
5. Measure minutes saved per job, edit rate, and willingness to pay.
6. Do not scale ads until retention and repeat use are demonstrated.

## Competitive differentiation
Avoid "AI for everyone". Start with a single workflow for one trade, multilingual drafting, and a transparent list of missing facts. Build trust with human approval and no automatic sending.

## Revenue example (not a forecast)
At CHF 79/month:
- 10 customers = CHF 790 monthly recurring revenue
- 50 customers = CHF 3,950 MRR
- 100 customers = CHF 7,900 MRR

Revenue is not profit. Subtract hosting, model inference, support, payment processing, taxes, sales and compliance costs.

## Risks and mitigations
- Hallucinated prices/scope: never calculate or send binding quotes without explicit human review.
- Customer confidentiality: minimise data; don't use identifiable client data in public demos; review provider retention/data location.
- Low willingness to pay: validate with interviews and paid pilots before building more features.
- Existing software competition: integrate into current workflows later; start with one underserved multilingual use case.
- Model instability: evaluate on a test set, compare outputs, and provide template fallback.

## 30-day validation goals
- 10 customer interviews
- 3 design partners
- 20 anonymised test cases
- 80% of drafts rated "usable after light edits" by pilot users (target to test, not achieved)
- Documented average time saved and willingness to pay
