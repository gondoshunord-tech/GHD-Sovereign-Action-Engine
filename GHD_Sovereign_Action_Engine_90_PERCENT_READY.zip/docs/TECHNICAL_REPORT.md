# Technical report — BuildMate

## Purpose
Prototype an AI-assisted drafting workflow for Swiss construction and cleaning SMEs. The system helps prepare draft customer replies, quote outlines and job summaries from user-provided notes.

## Architecture
- Browser UI: HTML, CSS, JavaScript.
- Backend: Python + Flask.
- Model adapter: optional OpenAI-compatible chat-completions request, configured via environment variables.
- Fallback: deterministic template when no provider is configured or the model call fails.
- Storage: none; requests are processed in memory and not persisted by this app.

## Model configuration
- Intended model default: `swiss-ai/Apertus-v1.5-8B`.
- `LLM_BASE_URL` and `LLM_API_KEY` are blank by default.
- The model adapter has not been verified against any provider in this package.
- A provider may use a different base URL, model identifier, authentication scheme, or request/response schema. Adapt and test before submission.
- Never claim Apertus was used unless the live response path has been successfully tested.

## Safety and limitations
- Model outputs can be inaccurate, incomplete, biased, or overconfident.
- Prices, scope, deadlines, tax treatment, and legal obligations must be checked by a human.
- Do not use personal or confidential customer data in unapproved endpoints.
- No authentication, roles, audit trail, persistent storage, rate limiting, or production hardening.
- No email sending, invoicing, or binding quote functionality.
- Demo fallback is not model output.

## Evaluation plan
Build an anonymised test set of at least 20 customer requests across cleaning and construction. For each output, score:
1. Factual consistency with the input (0–2).
2. Completeness of missing-detail checklist (0–2).
3. Language clarity (0–2).
4. Usefulness after light edits (0–2).
5. Whether it invents a price/date/commitment (yes/no; any such case is a failure requiring mitigation).

Compare model output with the template fallback, record model/version, latency, errors, and human ratings. Report results honestly; no benchmark has yet been run.

## Reproducibility
Run with `python app.py` or Docker. See README.md. `/health` reports whether an endpoint is configured. Test both the no-provider fallback and a verified provider connection.
