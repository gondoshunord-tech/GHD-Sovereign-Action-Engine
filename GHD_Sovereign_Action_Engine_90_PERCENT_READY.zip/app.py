import os, json, re, time, uuid, urllib.request, urllib.error
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)
MODEL = os.getenv('LLM_NAME','swiss-ai/Apertus-v1.1-4B-Instruct')
BASE = os.getenv('LLM_BASE_URL','').rstrip('/')
KEY = os.getenv('LLM_API_KEY','')
MAX_CHARS = int(os.getenv('MAX_INPUT_CHARS','18000'))

SYSTEM = '''You are the reasoning core inside G H D Sovereign Action Engine.
Turn messy operational information into a transparent, reviewable decision brief.
Rules:
- Never invent facts, sources, numbers, deadlines or legal conclusions.
- Separate source-backed evidence from inference.
- If a required fact is absent, mark it missing.
- Prefer a concrete next action over generic advice.
- Human approval is mandatory before any external action.
Return ONLY valid JSON with exactly these keys:
summary (string), facts (array of objects: claim,evidence,confidence), critical_issues (array strings), missing_inputs (array strings), recommended_action (string), draft_action (string), uncertainty (array strings).
confidence must be one of: source-backed, inferred, uncertain.'''

def endpoint():
    if not BASE: return ''
    if BASE.endswith('/chat/completions'): return BASE
    if BASE.endswith('/v1'): return BASE + '/chat/completions'
    return BASE + '/v1/chat/completions'

def extract_json(raw):
    raw = raw.strip()
    raw = re.sub(r'^```(?:json)?\s*|\s*```$', '', raw, flags=re.I|re.S)
    try: return json.loads(raw)
    except Exception:
        m = re.search(r'\{.*\}', raw, flags=re.S)
        if not m: raise
        return json.loads(m.group(0))

def normalize(x):
    if not isinstance(x, dict): raise ValueError('Model did not return an object')
    facts=[]
    for f in x.get('facts',[])[:12]:
        if isinstance(f,dict):
            facts.append({'claim':str(f.get('claim',''))[:500], 'evidence':str(f.get('evidence',''))[:500], 'confidence':str(f.get('confidence','uncertain'))[:30]})
    return {
      'summary': str(x.get('summary',''))[:1000], 'facts': facts,
      'critical_issues':[str(v)[:500] for v in x.get('critical_issues',[])[:10]],
      'missing_inputs':[str(v)[:500] for v in x.get('missing_inputs',[])[:10]],
      'recommended_action':str(x.get('recommended_action',''))[:1200],
      'draft_action':str(x.get('draft_action',''))[:2000],
      'uncertainty':[str(v)[:500] for v in x.get('uncertainty',[])[:10]]
    }

def call_apertus(text, context):
    ep=endpoint()
    if not ep: return None, {'label':'DEMO ENGINE','latency_ms':None,'error':'No Apertus endpoint configured.'}
    payload={'model':MODEL,'messages':[{'role':'system','content':SYSTEM},{'role':'user','content':f'WORKFLOW / CHALLENGE:\n{context}\n\nSOURCE INPUT:\n{text}'}], 'temperature':0.1, 'max_tokens':1800}
    headers={'Content-Type':'application/json'}
    if KEY: headers['Authorization']='Bearer '+KEY
    t=time.perf_counter()
    try:
        req=urllib.request.Request(ep,data=json.dumps(payload).encode(),headers=headers,method='POST')
        with urllib.request.urlopen(req,timeout=90) as r: data=json.loads(r.read().decode())
        raw=data['choices'][0]['message']['content']
        result=normalize(extract_json(raw))
        return result, {'label':'LIVE APERTUS','latency_ms':round((time.perf_counter()-t)*1000),'error':None}
    except Exception as e:
        return None, {'label':'SAFE FALLBACK','latency_ms':round((time.perf_counter()-t)*1000),'error':f'{type(e).__name__}: {str(e)[:160]}'}

def demo(text):
    parts=[x.strip(' -•\t') for x in re.split(r'(?<=[.!?])\s+|\n+',text) if x.strip()]
    facts=[{'claim':x[:350],'evidence':'Directly stated in source input','confidence':'source-backed'} for x in parts[:8]]
    low=text.lower(); missing=[]
    checks=[(['deadline','date','handover','today','tomorrow','monday','tuesday','wednesday','thursday','friday','saturday','sunday'],'exact deadline / date'),(['chf','price','cost','amount','budget','€','$'],'price / budget'),(['sqm','m2','m²','square metre','size','quantity'],'scope / quantity'),(['address','location','site','street'],'location / site')]
    for keys,label in checks:
        if not any(k in low for k in keys): missing.append(label)
    issues=[]
    if any(k in low for k in ['urgent','asap','critical','immediately']): issues.append('Time-sensitive request detected')
    if missing: issues.append('Decision is blocked by missing inputs')
    return {'summary':'Source input converted into an evidence-linked decision brief.','facts':facts,'critical_issues':issues,'missing_inputs':missing,'recommended_action':'Confirm the missing inputs, then review and approve the prepared next action.' if missing else 'Review the evidence and approve the prepared next action.','draft_action':'Request the missing information and prepare the operational response. Do not send anything until a human approves it.','uncertainty':['Deterministic demo mode: no model inference was used.']}

@app.get('/')
def home(): return render_template('index.html')

@app.get('/health')
def health(): return jsonify(ok=True, app='G H D Sovereign Action Engine', live_apertus=bool(BASE), endpoint=endpoint() if BASE else None, model=MODEL)

@app.post('/api/analyze')
def analyze():
    d=request.get_json(silent=True) or {}; text=str(d.get('text',''))[:MAX_CHARS]; context=str(d.get('context','General operational decision'))[:300]
    if not text.strip(): return jsonify(error='Add source input first.'),400
    result,meta=call_apertus(text,context); live=result is not None
    if result is None: result=demo(text)
    return jsonify(run_id=str(uuid.uuid4())[:8], result=result, live_ai=live, model=MODEL if live else None, meta=meta)

@app.post('/api/decision')
def decision():
    d=request.get_json(silent=True) or {}; choice=str(d.get('choice','')).lower(); note=str(d.get('note',''))[:1000]
    if choice not in {'approve','edit','reject'}: return jsonify(error='Invalid decision.'),400
    return jsonify(ok=True, choice=choice, note=note, timestamp=int(time.time()), message={'approve':'Approved for the next human-controlled step.','edit':'Marked for human editing.','reject':'Rejected. No action taken.'}[choice])

if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.getenv('PORT','8000')),debug=False)
