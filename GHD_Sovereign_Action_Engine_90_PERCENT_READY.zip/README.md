# G H D — Sovereign Action Engine

Hackathon-ready decision layer built around Apertus. It converts messy operational input into **source-backed facts → visible uncertainty → a reviewable next action → explicit human approval**.

## Why this is different
G H D is deliberately not a generic chatbot. The UI exposes an evidence ledger, missing inputs, critical issues, the prepared action, and an approval gate. Nothing is presented as automatically sent or executed.

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python app.py
```
Open `http://localhost:8000`.

## Connect Apertus
Copy `.env.example` values into your environment. `LLM_BASE_URL` can be a server root, `/v1`, or full `/chat/completions` endpoint. The app normalizes it to an OpenAI-compatible chat-completions call.

Example with a locally served instruct model:
```bash
vllm serve swiss-ai/Apertus-v1.1-4B-Instruct
export LLM_BASE_URL=http://localhost:8000
export LLM_NAME=swiss-ai/Apertus-v1.1-4B-Instruct
python app.py
```

If no endpoint is configured—or the live call fails—the product clearly switches to **DEMO ENGINE / SAFE FALLBACK**. It never pretends the fallback is Apertus inference.

## Challenge-day adaptation
Change the workflow label and source input first. Then tune the system prompt/schema only where the revealed challenge requires it. Keep the core contract intact: evidence, uncertainty, human control, measurable outcome.

## Benchmark plan
Before the final pitch, run a small fixed test set and record real values only:
- time per task before vs. with G H D
- factual errors / unsupported claims
- human edits required
- number of test cases
- live Apertus latency

Never replace these with invented numbers.

## Key endpoints
- `GET /health` — engine/model status
- `POST /api/analyze` — evidence-linked decision brief
- `POST /api/decision` — approve/edit/reject audit event

## Pitch line
**The future is not more AI. It’s better action.**
